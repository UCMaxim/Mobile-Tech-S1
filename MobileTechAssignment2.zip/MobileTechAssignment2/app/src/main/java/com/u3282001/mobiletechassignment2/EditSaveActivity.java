package com.u3282001.mobiletechassignment2;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class EditSaveActivity extends AppCompatActivity {

    private EditText etTitle;
    private EditText etResults;
    private ImageView imgPreview;

    private String readerType;
    private String mlKitResult;
    private String imageUriString;
    private boolean isNew;
    private String existingFilename;
    private String existingKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_save);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Get data passed from CameraGalleryActivity or DetailActivity
        readerType = getIntent().getStringExtra("readerType");
        mlKitResult = getIntent().getStringExtra("mlKitResult");
        imageUriString = getIntent().getStringExtra("imageUri");
        isNew = getIntent().getBooleanExtra("isNew", true);
        existingFilename = getIntent().getStringExtra("filename");
        existingKey = getIntent().getStringExtra("firebaseKey");

        etTitle = findViewById(R.id.etTitle);
        etResults = findViewById(R.id.etResults);
        imgPreview = findViewById(R.id.imgPreview);
        Button btnSave = findViewById(R.id.btnSave);

        // Set title based on reader type
        String titleText = "";
        switch (readerType) {
            case "barcode": titleText = "Barcode Reader"; break;
            case "content": titleText = "Content Reader"; break;
            case "text":    titleText = "Text Reader";    break;
        }
        etTitle.setText(titleText);
        etResults.setText(mlKitResult);

        // Load image
        if (imageUriString != null) {
            if (isNew) {
                // Coming from CameraGalleryActivity - load from URI
                imgPreview.setImageURI(Uri.parse(imageUriString));
            } else {
                // Coming from DetailActivity - load from internal storage
                File imgFile = new File(imageUriString);
                if (imgFile.exists()) {
                    imgPreview.setImageBitmap(BitmapFactory.decodeFile(imgFile.getAbsolutePath()));
                }
            }
        }

        btnSave.setOnClickListener(v -> saveData());

    }

    private void saveData() {
        String titleToSave = etTitle.getText().toString();
        String resultToSave = etResults.getText().toString();

        DatabaseReference dbRef = FirebaseDatabase.getInstance(
                        "https://assignment2mobiletech-default-rtdb.firebaseio.com/")
                .getReference("Storage");

        if (isNew) {
            String filename = new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.getDefault())
                    .format(new Date());

            saveImageToInternalStorage(filename);

            String key = dbRef.push().getKey();

            Map<String, String> data = new HashMap<>();
            data.put("filename", filename);
            data.put("reader", titleToSave);
            data.put("text", resultToSave);

            dbRef.child(key).setValue(data)
                    .addOnSuccessListener(aVoid -> {
                        android.util.Log.d("FIREBASE", "Data saved successfully");
                        Intent intent = new Intent(this, ListViewActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    })
                    .addOnFailureListener(e -> {
                        android.util.Log.e("FIREBASE", "Failed to save: " + e.getMessage());
                    });

        } else {
            dbRef.child(existingKey).child("reader").setValue(titleToSave);
            dbRef.child(existingKey).child("text").setValue(resultToSave)
                    .addOnSuccessListener(aVoid -> {
                        android.util.Log.d("FIREBASE", "Data updated successfully");
                        Intent intent = new Intent(this, ListViewActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    })
                    .addOnFailureListener(e -> {
                        android.util.Log.e("FIREBASE", "Failed to update: " + e.getMessage());
                    });
        }
    }

    private void saveImageToInternalStorage(String filename) {
        try {
            Uri imageUri = Uri.parse(imageUriString);
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

            // Save to internal storage
            FileOutputStream fos = openFileOutput(filename + ".jpg", Context.MODE_PRIVATE);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}