package com.u3282001.mobiletechassignment2;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;
import java.util.List;

public class CameraGalleryActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSION = 3000;
    private Uri imageFileUri;
    private String readerType;
    private String mlKitResult = "";

    private ImageView imgPreview;
    private TextView tvTitle;
    private TextView tvInstruction;
    private Button btnEditResult;
    private Button btnOpenCamera;
    private Button btnLoadImage;

    // Single launcher for both camera and gallery - matches tutorial pattern
    ActivityResultLauncher<Intent> activityResultLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    new ActivityResultCallback<ActivityResult>() {
                        @Override
                        public void onActivityResult(ActivityResult result) {
                            if (result.getResultCode() == RESULT_OK) {
                                // Gallery returns URI in data; camera uses imageFileUri we set before launch
                                if (result.getData() != null && result.getData().getData() != null)
                                    imageFileUri = result.getData().getData();

                                imgPreview.setImageURI(imageFileUri);

                                // Clear previous results and run ML Kit
                                tvInstruction.setText("");
                                InputImage image = null;
                                try {
                                    image = InputImage.fromFilePath(getBaseContext(), imageFileUri);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                if (image != null) {
                                    switch (readerType) {
                                        case "barcode":
                                            processImageFromBarcodeReader(image);
                                            break;
                                        case "content":
                                            processImageFromContentReader(image);
                                            break;
                                        case "text":
                                            processImageFromTextReader(image);
                                            break;
                                    }
                                }
                            }
                        }
                    });

    // Matches tutorial checkPermission method exactly
    private boolean checkPermission() {
        String permission = android.Manifest.permission.CAMERA;
        boolean grantCamera = ContextCompat.checkSelfPermission(this, permission)
                == PackageManager.PERMISSION_GRANTED;
        if (!grantCamera) {
            ActivityCompat.requestPermissions(this,
                    new String[]{permission}, REQUEST_PERMISSION);
        }
        return grantCamera;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_camera_gallery);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        readerType = getIntent().getStringExtra("readerType");

        imgPreview = findViewById(R.id.imgPreview);
        tvTitle = findViewById(R.id.tvTitle);
        tvInstruction = findViewById(R.id.tvInstruction);
        btnEditResult = findViewById(R.id.btnEditResult);
        btnOpenCamera = findViewById(R.id.btnOpenCamera);
        btnLoadImage = findViewById(R.id.btnLoadImage);

        // Show correct default image based on which reader was tapped
        if (readerType != null) {
            switch (readerType) {
                case "barcode":
                    imgPreview.setImageResource(R.drawable.barcode);
                    break;
                case "content":
                    imgPreview.setImageResource(R.drawable.content);
                    break;
                case "text":
                    imgPreview.setImageResource(R.drawable.text);
                    break;
            }
        }

        btnOpenCamera.setOnClickListener(v -> openCamera());
        btnLoadImage.setOnClickListener(v -> openGallery());

        btnEditResult.setOnClickListener(v -> {
            Intent intent = new Intent(this, EditSaveActivity.class);
            intent.putExtra("readerType", readerType);
            intent.putExtra("mlKitResult", mlKitResult);
            intent.putExtra("imageUri", imageFileUri.toString());
            intent.putExtra("isNew", true);
            startActivity(intent);
        });
    }

    // Matches tutorial openCamera method
    public void openCamera() {
        if (!checkPermission()) return;
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        imageFileUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new ContentValues());
        takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(takePhotoIntent);
    }

    // Matches tutorial loadImage method
    public void openGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        activityResultLauncher.launch(galleryIntent);
    }

    // Called after ML Kit finishes - updates title and shows Edit Result button
    private void updateUIAfterMLKit() {
        switch (readerType) {
            case "barcode":
                tvTitle.setText("Barcode Reader");
                break;
            case "content":
                tvTitle.setText("Content Reader");
                break;
            case "text":
                tvTitle.setText("Text Reader");
                break;
        }
        btnEditResult.setVisibility(View.VISIBLE);
    }

    // Matches tutorial processImageFromBarcodeReader exactly
    public void processImageFromBarcodeReader(InputImage image) {
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build();
        BarcodeScanner scanner = BarcodeScanning.getClient(options);
        scanner.process(image)
                .addOnSuccessListener(barcodes -> {
                    tvInstruction.setText("Detected barcode:\n");
                    String result = "";
                    int counter = 1;
                    for (Barcode barcode : barcodes) {
                        result = barcode.getRawValue();
                        tvInstruction.append(counter + ". " + result + "\n");
                        counter++;
                    }
                    if (result.length() < 2) {
                        tvInstruction.append("Barcode not found.\n");
                    }
                    mlKitResult = tvInstruction.getText().toString();
                    updateUIAfterMLKit();
                })
                .addOnFailureListener(e -> tvInstruction.setText("Failed"));
    }

    // Matches tutorial processImageFromContentReader exactly
    public void processImageFromContentReader(InputImage image) {
        ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);
        labeler.process(image)
                .addOnSuccessListener(labels -> {
                    tvInstruction.setText("");
                    if (labels.size() == 0) {
                        tvInstruction.append("Nothing found in the image\n");
                        return;
                    }
                    tvInstruction.append("Recognised image content:\n");
                    int counter = 1;
                    for (ImageLabel label : labels) {
                        String result = label.getText();
                        float confidence = label.getConfidence();
                        tvInstruction.append(counter + ". " + result +
                                " (" + String.format("%.1f", confidence * 100.0f) + "% confidence)\n");
                        counter++;
                    }
                    mlKitResult = tvInstruction.getText().toString();
                    updateUIAfterMLKit();
                })
                .addOnFailureListener(e -> tvInstruction.setText("Failed"));
    }

    // Matches tutorial processImageFromTextReader exactly
    public void processImageFromTextReader(InputImage image) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
                .addOnSuccessListener(visionText -> {
                    tvInstruction.setText("Extracted text:\n");
                    String result = visionText.getText();
                    if (result.length() > 1)
                        tvInstruction.append(result + "\n");
                    else
                        tvInstruction.append("No text found.\n");
                    mlKitResult = tvInstruction.getText().toString();
                    updateUIAfterMLKit();
                })
                .addOnFailureListener(e -> tvInstruction.setText("Failed"));
    }
}