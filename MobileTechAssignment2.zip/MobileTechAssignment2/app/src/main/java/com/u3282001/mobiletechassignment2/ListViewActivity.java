package com.u3282001.mobiletechassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ListViewActivity extends AppCompatActivity {

    private List<DataItem> itemList = new ArrayList<>();
    private ImageListAdapter adapter;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_list_view);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listView = findViewById(R.id.listView);
        Button btnAdd = findViewById(R.id.btnAdd);

        adapter = new ImageListAdapter(this, itemList);
        listView.setAdapter(adapter);

        // Tap item - open DetailActivity
        listView.setOnItemClickListener((parent, view, position, id) -> {
            DataItem item = itemList.get(position);
            Intent intent = new Intent(this, DetailActivity.class);
            intent.putExtra("firebaseKey", item.getKey());
            intent.putExtra("filename", item.getFilename());
            intent.putExtra("reader", item.getReader());
            intent.putExtra("text", item.getText());
            startActivity(intent);
        });

        // Add button opens MainActivity
        btnAdd.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadFromFirebase();
    }

    private void loadFromFirebase() {
        DatabaseReference dbRef = FirebaseDatabase.getInstance("https://assignment2mobiletech-default-rtdb.firebaseio.com/").getReference("Storage");
        dbRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                itemList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    String key = child.getKey();
                    String filename = child.child("filename").getValue(String.class);
                    String reader = child.child("reader").getValue(String.class);
                    String text = child.child("text").getValue(String.class);
                    itemList.add(new DataItem(key, filename, reader, text));
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        });
    }
}