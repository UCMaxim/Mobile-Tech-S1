package com.u3282001.mobiletechassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Find all views
        ImageView imgBarcode = findViewById(R.id.imgBarcode);
        ImageView imgContent = findViewById(R.id.imgContent);
        ImageView imgText = findViewById(R.id.imgText);
        Button btnList = findViewById(R.id.btnListAnalysedImages);

        // Each image opens CameraGalleryActivity with a readerType tag
        imgBarcode.setOnClickListener(v -> openCameraGallery("barcode"));
        imgContent.setOnClickListener(v -> openCameraGallery("content"));
        imgText.setOnClickListener(v -> openCameraGallery("text"));

        // List button opens ListViewActivity
        btnList.setOnClickListener(v -> {
            Intent intent = new Intent(this, ListViewActivity.class);
            startActivity(intent);
        });
    }

    private void openCameraGallery(String readerType) {
        Intent intent = new Intent(this, CameraGalleryActivity.class);
        intent.putExtra("readerType", readerType);
        startActivity(intent);
    }
}
