package com.u3282001.mobiletechassignment2;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;

public class DetailActivity extends AppCompatActivity {

    private String firebaseKey;
    private String filename;
    private String reader;
    private String text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Get data passed from ListViewActivity
        firebaseKey = getIntent().getStringExtra("firebaseKey");
        filename = getIntent().getStringExtra("filename");
        reader = getIntent().getStringExtra("reader");
        text = getIntent().getStringExtra("text");

        // Find views
        TextView tvTitle = findViewById(R.id.tvTitle);
        TextView tvResults = findViewById(R.id.tvResults);
        ImageView imgPreview = findViewById(R.id.imgPreview);
        Button btnEdit = findViewById(R.id.btnEdit);
        Button btnDelete = findViewById(R.id.btnDelete);
        Button btnCancel = findViewById(R.id.btnCancel);

        // Display data
        tvTitle.setText(reader);
        tvResults.setText(text);

        // Load image from internal storage
        File imgFile = getFileStreamPath(filename + ".jpg");
        if (imgFile.exists()) {
            imgPreview.setImageBitmap(
                    BitmapFactory.decodeFile(imgFile.getAbsolutePath()));
        }

        // Edit button - open EditSaveActivity with existing item data
        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(this, EditSaveActivity.class);
            intent.putExtra("readerType", readerTypeFromReader(reader));
            intent.putExtra("mlKitResult", text);
            intent.putExtra("imageUri", imgFile.getAbsolutePath());
            intent.putExtra("isNew", false);
            intent.putExtra("filename", filename);
            intent.putExtra("firebaseKey", firebaseKey);
            startActivity(intent);
        });

        // Delete button - remove from Firebase then go to ListViewActivity
        btnDelete.setOnClickListener(v -> {
            DatabaseReference dbRef = FirebaseDatabase.getInstance()
                    .getReference("Storage");
            dbRef.child(firebaseKey).removeValue();

            Intent intent = new Intent(this, ListViewActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

        // Cancel button - go back to ListViewActivity with no changes
        btnCancel.setOnClickListener(v -> {
            Intent intent = new Intent(this, ListViewActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }

    // Convert reader display name back to readerType key
    private String readerTypeFromReader(String reader) {
        switch (reader) {
            case "Barcode Reader": return "barcode";
            case "Content Reader": return "content";
            case "Text Reader":    return "text";
            default:               return "barcode";
        }
    }
}