package com.u3282001.mobiletechassignment2;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import java.io.File;
import java.util.List;

public class ImageListAdapter extends ArrayAdapter<DataItem> {

    private final Context context;
    private final List<DataItem> items;

    public ImageListAdapter(Context context, List<DataItem> items) {
        super(context, 0, items);
        this.context = context;
        this.items = items;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.list_item, parent, false);
        }

        DataItem item = items.get(position);

        ImageView imgItem = convertView.findViewById(R.id.imgItem);
        TextView tvItem = convertView.findViewById(R.id.tvItem);
        TextView tvSubItem = convertView.findViewById(R.id.tvSubItem);

        // Alternating background colours
        if (position % 2 == 0) {
            convertView.setBackgroundColor(0xFFFFFFFF); // white
        } else {
            convertView.setBackgroundColor(0xFFDDDDDD); // grey
        }

        // Load image from internal storage
        File imgFile = context.getFileStreamPath(item.getFilename() + ".jpg");
        if (imgFile.exists()) {
            imgItem.setImageBitmap(
                    BitmapFactory.decodeFile(imgFile.getAbsolutePath()));
        }

        // Show reader name and result
        tvItem.setText(item.getReader());
        // Show result on one line (replace newlines with spaces like tutorial)
        tvSubItem.setText(item.getText().replaceAll("\n", " "));

        return convertView;
    }
}