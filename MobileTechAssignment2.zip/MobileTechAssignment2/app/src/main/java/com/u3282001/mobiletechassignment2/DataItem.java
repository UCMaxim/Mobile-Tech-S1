package com.u3282001.mobiletechassignment2;

public class DataItem {
    private String key;
    private String filename;
    private String reader;
    private String text;

    public DataItem() {}

    public DataItem(String key, String filename, String reader, String text) {
        this.key = key;
        this.filename = filename;
        this.reader = reader;
        this.text = text;
    }

    public String getKey() { return key; }
    public String getFilename() { return filename; }
    public String getReader() { return reader; }
    public String getText() { return text; }

    public void setKey(String key) { this.key = key; }
    public void setFilename(String filename) { this.filename = filename; }
    public void setReader(String reader) { this.reader = reader; }
    public void setText(String text) { this.text = text; }
}